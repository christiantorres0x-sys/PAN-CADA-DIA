<?php
require_once __DIR__ . '/db.php';
require_login();

$id = (int)($_GET['id'] ?? 0);
$isEdit = $id > 0;

$beneficiary = [
    'full_name' => '',
    'birth_date' => '',
    'sex' => 'Male',
    'grade_level' => '',
    'site_id' => '',
    'program_id' => '',
    'program_status' => 'ENROLLED',
    'date_enlisted' => '',
    'remarks' => '',
];

if ($isEdit) {
    $stmt = $pdo->prepare("SELECT * FROM beneficiaries WHERE beneficiary_id=?");
    $stmt->execute([$id]);
    $beneficiary = $stmt->fetch();
    if (!$beneficiary) exit('Beneficiary not found.');
}

// The form splits the stored full_name into First / Last for editing; a
// lone name has no split (last name left blank) rather than guessing wrong.
$nameParts = trim($beneficiary['full_name']) !== '' ? preg_split('/\s+/', trim($beneficiary['full_name'])) : [];
$firstName = $nameParts ? array_shift($nameParts) : '';
$lastName = $nameParts ? implode(' ', $nameParts) : '';

$sites = $pdo->query("SELECT * FROM feeding_sites WHERE status='ACTIVE' ORDER BY site_name")->fetchAll();
$programs = $pdo->query("SELECT * FROM feeding_programs WHERE status <> 'INACTIVE' ORDER BY start_date DESC, program_name")->fetchAll();

$gradeLevelOptions = ['Day Care', 'Kinder', 'Grade 1', 'Grade 2', 'Grade 3', 'Grade 4', 'Grade 5', 'Grade 6'];
if ($beneficiary['grade_level'] !== '' && !in_array($beneficiary['grade_level'], $gradeLevelOptions, true)) {
    $gradeLevelOptions[] = $beneficiary['grade_level'];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $fullName = trim(trim($_POST['first_name'] ?? '') . ' ' . trim($_POST['last_name'] ?? ''));

    $data = [
        $fullName,
        $_POST['birth_date'] ?? '',
        $_POST['sex'] ?? 'Male',
        trim($_POST['grade_level'] ?? ''),
        ($_POST['site_id'] ?? '') !== '' ? (int)$_POST['site_id'] : null,
        ($_POST['program_id'] ?? '') !== '' ? (int)$_POST['program_id'] : null,
        $_POST['program_status'] ?? 'ENROLLED',
        ($_POST['date_enlisted'] ?? '') !== '' ? $_POST['date_enlisted'] : null,
        trim($_POST['remarks'] ?? ''),
    ];

    if ($data[0] === '' || $data[1] === '') {
        flash('danger', 'First name and birthdate are required.');
        header('Location: beneficiary_form.php' . ($isEdit ? '?id=' . $id : ''));
        exit;
    }

    if ($isEdit) {
        $sql = "UPDATE beneficiaries SET full_name=?, birth_date=?, sex=?, grade_level=?, site_id=?, program_id=?, program_status=?, date_enlisted=?, remarks=? WHERE beneficiary_id=?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([...$data, $id]);
        log_action($pdo, 'UPDATE_BENEFICIARY', 'beneficiaries', $id, 'Updated beneficiary profile');
        flash('success', 'Beneficiary updated.');
        header('Location: beneficiary.php?id=' . $id);
        exit;
    }

    // Optional baseline capture, shown directly on the Add form. This is a
    // soft step: the beneficiary is created either way. Both height and
    // weight must be given together for a baseline to be recorded; a lone
    // value is treated as "not enough to record yet" rather than an error,
    // since the officer may just be filling the form out ahead of the
    // actual weigh-in.
    $baselineHeight = (float)($_POST['baseline_height_cm'] ?? 0);
    $baselineWeight = (float)($_POST['baseline_weight_kg'] ?? 0);
    $baselineDate = ($_POST['baseline_date'] ?? '') !== '' ? $_POST['baseline_date'] : date('Y-m-d');
    $weightStatus = trim($_POST['weight_status'] ?? '');
    $baselineRemarks = trim($_POST['baseline_remarks'] ?? '');
    $hasBaselineMeasurement = $baselineHeight > 0 && $baselineWeight > 0;

    $pdo->beginTransaction();
    try {
        $sql = "INSERT INTO beneficiaries (full_name, birth_date, sex, grade_level, site_id, program_id, program_status, date_enlisted, remarks) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($data);
        $newId = (int)$pdo->lastInsertId();
        log_action($pdo, 'CREATE_BENEFICIARY', 'beneficiaries', $newId, 'Created beneficiary profile');

        if ($hasBaselineMeasurement) {
            $bmi = calculate_bmi($baselineWeight, $baselineHeight);
            $stmt = $pdo->prepare("
                INSERT INTO health_records
                (beneficiary_id, record_date, milestone, height_cm, weight_kg, bmi, nutritional_status, remarks, recorded_by)
                VALUES (?, ?, 'BASELINE', ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([$newId, $baselineDate, $baselineHeight, $baselineWeight, $bmi, $weightStatus !== '' ? $weightStatus : null, $baselineRemarks, $_SESSION['user_id']]);
            log_action($pdo, 'CREATE_HEALTH_RECORD', 'health_records', (int)$pdo->lastInsertId(), 'Baseline captured during enrollment; BMI ' . $bmi);
        }

        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        flash('danger', 'Could not save beneficiary. Please try again.');
        header('Location: beneficiary_form.php');
        exit;
    }

    if ($hasBaselineMeasurement) {
        flash('success', 'Beneficiary added and baseline recorded.');
    } else {
        flash('success', 'Beneficiary added. Baseline is still pending — add it from the profile page once the child is weighed.');
    }
    header('Location: beneficiary.php?id=' . $newId);
    exit;
}

$pageTitle = $isEdit ? 'Edit Beneficiary' : 'Add Beneficiary';
$pageEyebrowHtml = '<a class="back-link" href="' . ($isEdit ? 'beneficiary.php?id=' . $id : 'beneficiaries.php') . '">&larr; Back to ' . ($isEdit ? 'Beneficiary Profile' : 'Dashboard') . '</a>';
require __DIR__ . '/partials/header.php';
?>
<section class="panel form-panel">
    <form method="post">
        <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
        <div class="form-grid">
            <div>
                <label>Status *</label>
                <select name="program_status">
                    <option value="ENROLLED" <?= $beneficiary['program_status'] === 'ENROLLED' ? 'selected' : '' ?>>Enrolled</option>
                    <option value="COMPLETED" <?= $beneficiary['program_status'] === 'COMPLETED' ? 'selected' : '' ?>>Completed</option>
                    <option value="INACTIVE" <?= $beneficiary['program_status'] === 'INACTIVE' ? 'selected' : '' ?>>Inactive</option>
                </select>
            </div>
            <div>
                <label>Feeding Site *</label>
                <select name="site_id" required>
                    <option value="">Select site</option>
                    <?php foreach ($sites as $s): ?>
                        <option value="<?= $s['site_id'] ?>" <?= (string)$beneficiary['site_id'] === (string)$s['site_id'] ? 'selected' : '' ?>><?= e($s['site_name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label>First Name *</label>
                <input name="first_name" value="<?= e($firstName) ?>" required>
            </div>
            <div>
                <label>Last Name *</label>
                <input name="last_name" value="<?= e($lastName) ?>" required>
            </div>
            <div>
                <label>Birthdate *</label>
                <input type="date" name="birth_date" value="<?= e($beneficiary['birth_date']) ?>" required>
            </div>
            <div>
                <label>Sex *</label>
                <select name="sex">
                    <option <?= $beneficiary['sex'] === 'Male' ? 'selected' : '' ?>>Male</option>
                    <option <?= $beneficiary['sex'] === 'Female' ? 'selected' : '' ?>>Female</option>
                </select>
            </div>
            <div>
                <label>Grade Level *</label>
                <select name="grade_level" required>
                    <option value="">Select grade level</option>
                    <?php foreach ($gradeLevelOptions as $g): ?>
                        <option <?= $beneficiary['grade_level'] === $g ? 'selected' : '' ?>><?= e($g) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label>Feeding Program</label>
                <select name="program_id">
                    <option value="">Select program</option>
                    <?php foreach ($programs as $p): ?>
                        <option value="<?= $p['program_id'] ?>" <?= (string)$beneficiary['program_id'] === (string)$p['program_id'] ? 'selected' : '' ?>><?= e($p['program_name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label>Date Enlisted</label>
                <input type="date" name="date_enlisted" value="<?= e($beneficiary['date_enlisted']) ?>">
            </div>
        </div>

        <?php if (!$isEdit): ?>
        <div class="optional-section">
            <p class="muted" style="margin:0 0 8px;">Optional. You can add the baseline data later on the beneficiary's profile page instead.</p>
            <div class="form-grid">
                <div>
                    <label>Date of Measurement</label>
                    <input type="date" name="baseline_date" value="<?= date('Y-m-d') ?>">
                </div>
                <div>
                    <label>Height (cm)</label>
                    <input id="height_cm" type="number" name="baseline_height_cm" min="1" step="0.01">
                </div>
                <div>
                    <label>Weight (kgs)</label>
                    <input id="weight_kg" type="number" name="baseline_weight_kg" min="0.1" step="0.01">
                </div>
                <div>
                    <label>Calculated BMI</label>
                    <input id="bmi_preview" readonly placeholder="Enter height and weight">
                </div>
                <div>
                    <label>Weight Status</label>
                    <input name="weight_status" placeholder="Pending child growth reference">
                </div>
                <div class="full-col">
                    <label>Remarks</label>
                    <input name="baseline_remarks">
                </div>
            </div>
        </div>
        <?php endif; ?>

        <div class="form-actions">
            <a class="btn secondary" href="<?= $isEdit ? 'beneficiary.php?id=' . $id : 'beneficiaries.php' ?>">Cancel</a>
            <button class="btn primary"><?= $isEdit ? 'Update Beneficiary' : 'Add Beneficiary' ?></button>
        </div>
    </form>
</section>
<?php require __DIR__ . '/partials/footer.php'; ?>
