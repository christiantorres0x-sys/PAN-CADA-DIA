<?php
require_once __DIR__ . '/db.php';
require_login();

$total = (int)$pdo->query("SELECT COUNT(*) FROM beneficiaries")->fetchColumn();
$enrolled = (int)$pdo->query("SELECT COUNT(*) FROM beneficiaries WHERE program_status='ENROLLED'")->fetchColumn();
$sites = (int)$pdo->query("SELECT COUNT(*) FROM feeding_sites WHERE status='ACTIVE'")->fetchColumn();
$records = (int)$pdo->query("SELECT COUNT(*) FROM health_records")->fetchColumn();
$baselineDone = (int)$pdo->query("SELECT COUNT(*) FROM health_records WHERE milestone='BASELINE'")->fetchColumn();
$baselinePending = max(0, $total - $baselineDone);

$latest = $pdo->query("
    SELECT hr.*, b.full_name, b.birth_date, b.sex, b.grade_level, b.program_status, s.site_name
    FROM health_records hr
    JOIN beneficiaries b ON b.beneficiary_id = hr.beneficiary_id
    LEFT JOIN feeding_sites s ON s.site_id = b.site_id
    ORDER BY hr.record_date DESC, hr.record_id DESC
    LIMIT 8
")->fetchAll();
$recentSiteName = $latest[0]['site_name'] ?? null;
$recentSiteLabel = null;
if ($recentSiteName) {
    $recentSiteLabel = stripos($recentSiteName, 'feeding site') !== false
        ? 'From the ' . $recentSiteName
        : 'From the ' . $recentSiteName . ' Feeding Site';
}

$pageTitle = 'Dashboard';
$activeNav = 'dashboard.php';
require __DIR__ . '/partials/header.php';
?>
<div class="dash-top">
    <section class="stat">
        <span>Pending Enrollments</span>
        <strong><?= $baselinePending ?></strong>
        <a href="beneficiaries.php">Needs setup &rarr;</a>
    </section>

    <div class="quick-actions-col">
        <span>Quick Actions</span>
        <div class="quick-grid">
            <a class="btn primary" href="beneficiary_form.php">Add Beneficiary</a>
            <a class="btn secondary" href="beneficiaries.php">Manage Beneficiaries</a>
            <a class="btn secondary" href="attendance.php">Manage Attendance</a>
            <a class="btn secondary" href="reports.php">Create Report &amp; Analysis</a>
        </div>
    </div>
</div>

<section class="panel" style="margin-top:12px;">
    <div class="panel-head">
        <div>
            <h2>Recent Report</h2>
            <span class="muted" style="font-size:12.5px;"><?= $recentSiteLabel ? e($recentSiteLabel) : 'Latest measurements recorded across all sites' ?></span>
        </div>
        <a href="reports.php" style="font-size:12px; font-weight:800; text-transform:uppercase; letter-spacing:.4px;">View Current Report &amp; Analysis</a>
    </div>
    <?php if (!$latest): ?>
        <p class="empty">No health records yet.</p>
    <?php else: ?>
    <div class="table-wrap">
        <table>
            <thead>
                <tr><th>Grade Level</th><th>Birth Date</th><th>Name</th><th>Sex</th><th>Height</th><th>Weight</th><th>BMI</th><th>Weight Status</th><th>Status</th></tr>
            </thead>
            <tbody>
                <?php foreach ($latest as $r): ?>
                <tr>
                    <td><?= e($r['grade_level'] ?: '—') ?></td>
                    <td><?= e($r['birth_date']) ?></td>
                    <td><?= e($r['full_name']) ?></td>
                    <td><?= e($r['sex']) ?></td>
                    <td><?= e($r['height_cm']) ?> cm</td>
                    <td><?= e($r['weight_kg']) ?> kg</td>
                    <td><?= e($r['bmi']) ?> kg/m<sup>2</sup></td>
                    <td><?= $r['nutritional_status'] ? pcd_badge($r['nutritional_status']) : '<span class="muted">Pending</span>' ?></td>
                    <td><?= pcd_badge($r['program_status']) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</section>

<h2 style="margin:16px 0 8px;">Overview</h2>
<div class="cards">
    <div class="stat blue"><span>Total Beneficiaries</span><strong><?= $total ?></strong><small class="muted">All registered</small></div>
    <div class="stat orange"><span>Active Feeding Sites</span><strong><?= $sites ?></strong><small class="muted">Operating sites</small></div>
    <div class="stat gray"><span>Health Records</span><strong><?= $records ?></strong><small class="muted">Total measurements</small></div>
    <div class="stat orange"><span>Baseline Pending</span><strong><?= $baselinePending ?></strong><small class="muted"><?= $baselineDone ?> of <?= $total ?> profiled</small></div>
</div>
<?php require __DIR__ . '/partials/footer.php'; ?>
