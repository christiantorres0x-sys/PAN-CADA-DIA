<?php
require_once __DIR__ . '/db.php';
require_login();

$q = trim($_GET['q'] ?? '');
$siteId = (int)($_GET['site_id'] ?? 0);

$sites = $pdo->query("SELECT * FROM feeding_sites WHERE status='ACTIVE' ORDER BY site_name")->fetchAll();

$where = [];
$params = [];
if ($q !== '') {
    $where[] = '(b.full_name LIKE ? OR b.grade_level LIKE ?)';
    $like = "%$q%";
    $params[] = $like;
    $params[] = $like;
}
if ($siteId > 0) {
    $where[] = 'b.site_id = ?';
    $params[] = $siteId;
}
$whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

$stmt = $pdo->prepare("
    SELECT b.*, s.site_name, p.program_name
    FROM beneficiaries b
    LEFT JOIN feeding_sites s ON s.site_id=b.site_id
    LEFT JOIN feeding_programs p ON p.program_id=b.program_id
    $whereSql
    ORDER BY b.full_name
");
$stmt->execute($params);
$rows = $stmt->fetchAll();

// Latest health record per beneficiary, fetched once rather than N+1 per row.
$latestByBeneficiary = [];
$hrStmt = $pdo->query("SELECT * FROM health_records ORDER BY record_date DESC, record_id DESC");
foreach ($hrStmt->fetchAll() as $row) {
    $bid = $row['beneficiary_id'];
    if (!isset($latestByBeneficiary[$bid])) {
        $latestByBeneficiary[$bid] = $row;
    }
}

$pageTitle = 'Beneficiaries';
$pageSubtitle = "Click on each row to open a beneficiary's profile and record measurements.";
$pageActionsHtml = '<a class="btn primary" href="beneficiary_form.php"><svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg><span>Add Beneficiary</span></a>';
$activeNav = 'beneficiaries.php';
require __DIR__ . '/partials/header.php';
?>
<section class="panel">
    <span class="filter-label">Filters</span>
    <form class="scope-row" method="get">
        <?php if ($q !== ''): ?><input type="hidden" name="q" value="<?= e($q) ?>"><?php endif; ?>
        <div class="field">
            <label>Feeding Site</label>
            <select name="site_id">
                <option value="0">All feeding sites</option>
                <?php foreach ($sites as $s): ?>
                    <option value="<?= $s['site_id'] ?>" <?= $siteId === (int)$s['site_id'] ? 'selected' : '' ?>><?= e($s['site_name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <button class="btn primary">Search</button>
    </form>
</section>

<div class="toolbar">
    <form class="search" method="get">
        <?php if ($siteId > 0): ?><input type="hidden" name="site_id" value="<?= $siteId ?>"><?php endif; ?>
        <input name="q" value="<?= e($q) ?>" placeholder="Enter Beneficiary's Name">
        <button class="btn icon-only" aria-label="Search"><svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4.3-4.3"/></svg></button>
    </form>
</div>

<section class="panel">
    <p class="list-count">Total Beneficiaries: <?= count($rows) ?></p>
    <div class="table-wrap">
        <table>
            <thead>
                <tr><th>Enroll Date</th><th>Beneficiary</th><th>Age</th><th>Sex</th><th>Height</th><th>Weight</th><th>BMI</th><th>Status</th></tr>
            </thead>
            <tbody>
                <?php foreach ($rows as $b): $rec = $latestByBeneficiary[$b['beneficiary_id']] ?? null; ?>
                <tr class="clickable-row" data-href="beneficiary.php?id=<?= (int)$b['beneficiary_id'] ?>" onclick="window.location=this.dataset.href">
                    <td><?= e($b['date_enlisted'] ?: '—') ?></td>
                    <td><strong><a href="beneficiary.php?id=<?= (int)$b['beneficiary_id'] ?>"><?= e($b['full_name']) ?></a></strong></td>
                    <td><?= age_in_years($b['birth_date']) ?></td>
                    <td><?= e($b['sex']) ?></td>
                    <td><?= $rec ? e($rec['height_cm']) . ' cm' : '—' ?></td>
                    <td><?= $rec ? e($rec['weight_kg']) . ' kg' : '—' ?></td>
                    <td><?= $rec ? e($rec['bmi']) . ' kg/m<sup>2</sup>' : '—' ?></td>
                    <td><?= pcd_badge($b['program_status']) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php if (!$rows): ?>
            <p class="empty">No beneficiaries found.</p>
        <?php endif; ?>
    </div>
</section>
<?php require __DIR__ . '/partials/footer.php'; ?>
