# PAN CADA DIA – Feeding Program Health Monitoring System

A starter online/web-based health monitoring system for CCES, built with PHP + MySQL.

## Current MVP

- Login
- Beneficiary management
- Manual-sheet fields digitized
- Health measurements
- Automatic BMI calculation
- Health history
- Basic analysis
- Printable reports
- Online-ready MySQL structure

## Important health rule

BMI is calculated as:

BMI = weight (kg) / height(m)^2

This project intentionally does NOT use adult BMI categories for children. The final nutritional classification must use the correct age- and sex-specific child growth reference after CCES confirms the beneficiary age range and preferred standard.

## Run locally with XAMPP

1. Install XAMPP.
2. Start Apache and MySQL.
3. Copy this `PAN_CADA_DIA` folder into:
   `C:\xampp\htdocs\`
4. Open phpMyAdmin:
   `http://localhost/phpmyadmin`
5. Import `setup.sql`.
6. Open:
   `http://localhost/PAN_CADA_DIA/`
7. Login:
   Username: `admin`
   Password: `admin123`

Change the development password before any real deployment.

## Next development tasks

1. Confirm beneficiary age range and exact nutritional classification standard.
2. Add WHO child BMI-for-age calculation/classification.
3. Add CCES's exact feeding sites/programs.
4. Add official report templates.
5. Add stronger production security, HTTPS, backups, and deployment configuration.
6. Conduct user acceptance testing with CCES.

## Code structure

- `partials/header.php` / `partials/footer.php` — the shared page shell (head, sidebar/nav, flash message, page-title block) used by every authenticated page. A page sets `$pageTitle` (and optionally `$pageSubtitle`, `$pageActionsHtml`, `$activeNav`) then requires `partials/header.php`; it closes the page by requiring `partials/footer.php`.
- `assets/css/` — split into `base.css` (variables/reset), `layout.css` (sidebar/nav app shell), `components.css` (cards, panels, buttons, tables, badges, alerts), `forms.css` (form fields, profile grid), `login.css` (login-page-only styles), and `responsive.css` (breakpoints + print). Authenticated pages load everything except `login.css`; the login page loads everything except `layout.css`/`responsive.css`.
- `config.php` — shared helper functions (`e()`, `flash()`, `pcd_badge()`, etc.) available on every page via `db.php`.

## Do not use real beneficiary data yet

Use dummy/test records during development until CCES formally authorizes the handling of real data and the production environment is secured.

\n## Phase 2 additions\n\n- Filterable reports by site, program, status, and date range\n- CSV report export\n- Age-at-measurement calculation\n- Feeding site/program configuration page\n- Audit logging for beneficiary and health-record changes\n- Safer child BMI workflow: no adult BMI classification\n\n### Current blocker before nutritional classification\nCCES still needs to confirm the beneficiary age range, exact nutritional classification standard/reference, and any required official report template. Do not invent those values in the production system.\n
## Phase 3 additions

- Daily attendance module for enrolled beneficiaries
- Present / Absent / Excused attendance statuses
- Duplicate-safe attendance per beneficiary/date
- Attendance history on each beneficiary profile
- Dashboard attendance snapshot

### Recommended next validation
Use sample data first. Before production use, CCES should confirm whether attendance is required daily, the exact attendance statuses they use, and whether attendance needs to be included in official reports.
