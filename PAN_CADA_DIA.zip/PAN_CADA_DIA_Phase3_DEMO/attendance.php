<?php
require_once __DIR__ . '/db.php';
require_login();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $bid = (int)($_POST['beneficiary_id'] ?? 0);
    $date = $_POST['attendance_date'] ?? date('Y-m-d');
    $status = $_POST['attendance_status'] ?? 'PRESENT';
    $remarks = trim($_POST['remarks'] ?? '');

    if (!in_array($status, ['PRESENT', 'ABSENT', 'EXCUSED'], true)) {
        $status = 'PRESENT';
    }

    $check = $pdo->prepare('SELECT beneficiary_id FROM beneficiaries WHERE beneficiary_id=?');
    $check->execute([$bid]);
    if (!$check->fetch()) {
        flash('danger', 'Beneficiary not found.');
        header('Location: attendance.php');
        exit;
    }

    $stmt = $pdo->prepare("
        INSERT INTO attendance_records (beneficiary_id, attendance_date, attendance_status, remarks, recorded_by)
        VALUES (?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE
            attendance_status = VALUES(attendance_status),
            remarks = VALUES(remarks),
            recorded_by = VALUES(recorded_by),
            updated_at = CURRENT_TIMESTAMP
    ");
    $stmt->execute([$bid, $date, $status, $remarks, $_SESSION['user_id']]);

    log_action($pdo, 'UPSERT_ATTENDANCE', 'attendance_records', null, 'Beneficiary ID ' . $bid . '; ' . $date . '; ' . $status);
    flash('success', 'Attendance saved.');
    header('Location: attendance.php?date=' . urlencode($date));
    exit;
}

$date = $_GET['date'] ?? date('Y-m-d');
$siteId = (int)($_GET['site_id'] ?? 0);
$programId = (int)($_GET['program_id'] ?? 0);

$sites = $pdo->query("SELECT * FROM feeding_sites WHERE status='ACTIVE' ORDER BY site_name")->fetchAll();
$programs = $pdo->query("SELECT * FROM feeding_programs WHERE status<>'INACTIVE' ORDER BY program_name")->fetchAll();

$where = ["b.program_status='ENROLLED'"];
$params = [];
if ($siteId > 0) {
    $where[] = 'b.site_id=?';
    $params[] = $siteId;
}
if ($programId > 0) {
    $where[] = 'b.program_id=?';
    $params[] = $programId;
}
$ws = 'WHERE ' . implode(' AND ', $where);

$stmt = $pdo->prepare("
    SELECT b.beneficiary_id, b.full_name, b.grade_level, s.site_name, p.program_name,
           ar.attendance_status, ar.remarks
    FROM beneficiaries b
    LEFT JOIN feeding_sites s ON s.site_id = b.site_id
    LEFT JOIN feeding_programs p ON p.program_id = b.program_id
    LEFT JOIN attendance_records ar ON ar.beneficiary_id = b.beneficiary_id AND ar.attendance_date = ?
    $ws
    ORDER BY b.full_name
");
$stmt->execute(array_merge([$date], $params));
$rows = $stmt->fetchAll();

$counts = ['PRESENT' => 0, 'ABSENT' => 0, 'EXCUSED' => 0, 'UNRECORDED' => 0];
foreach ($rows as $r) {
    $counts[$r['attendance_status'] ?: 'UNRECORDED']++;
}

$pageTitle = 'Attendance';
$pageActionsHtml = '<a class="btn primary" href="beneficiary_form.php"><svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg><span>Add Beneficiary</span></a>';
$activeNav = 'attendance.php';
require __DIR__ . '/partials/header.php';
?>
<section class="panel">
    <span class="filter-label">Filter</span>
    <form method="get">
        <div class="scope-row" style="margin-bottom:10px;">
            <div class="field">
                <label>Purpose</label>
                <select name="program_id">
                    <option value="0">All programs</option>
                    <?php foreach ($programs as $p): ?>
                        <option value="<?= $p['program_id'] ?>" <?= $programId === $p['program_id'] ? 'selected' : '' ?>><?= e($p['program_name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="field">
                <label>Date</label>
                <input type="date" name="date" value="<?= e($date) ?>">
            </div>
            <button class="btn primary">Manage Attendance</button>
        </div>
        <div class="field">
            <label>Feeding Site</label>
            <select name="site_id">
                <option value="0">All sites</option>
                <?php foreach ($sites as $s): ?>
                    <option value="<?= $s['site_id'] ?>" <?= $siteId === $s['site_id'] ? 'selected' : '' ?>><?= e($s['site_name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
    </form>
</section>

<div class="cards cards-3">
    <div class="stat green"><span>Present</span><strong><?= $counts['PRESENT'] ?></strong></div>
    <div class="stat red"><span>Absent</span><strong><?= $counts['ABSENT'] ?></strong></div>
    <div class="stat orange"><span>Excused</span><strong><?= $counts['EXCUSED'] ?></strong></div>
</div>

<section class="panel">
    <div class="panel-head">
        <h2><?= e($date) ?> — Enrolled Beneficiaries</h2>
        <span class="muted">Save each row to record or update attendance.</span>
    </div>
    <div class="table-wrap">
        <table>
            <thead>
                <tr><th>Beneficiary</th><th>Site</th><th>Program</th><th>Status</th><th>Remarks</th><th>Action</th></tr>
            </thead>
            <tbody>
                <?php foreach ($rows as $r): ?>
                <tr>
                    <form method="post">
                        <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
                        <input type="hidden" name="beneficiary_id" value="<?= $r['beneficiary_id'] ?>">
                        <input type="hidden" name="attendance_date" value="<?= e($date) ?>">
                    <td><a href="beneficiary.php?id=<?= $r['beneficiary_id'] ?>"><?= e($r['full_name']) ?></a></td>
                    <td><?= e($r['site_name'] ?? '—') ?></td>
                    <td><?= e($r['program_name'] ?? '—') ?></td>
                    <td>
                        <select name="attendance_status">
                            <option <?= ($r['attendance_status'] ?? '') === 'PRESENT' ? 'selected' : '' ?>>PRESENT</option>
                            <option <?= ($r['attendance_status'] ?? '') === 'ABSENT' ? 'selected' : '' ?>>ABSENT</option>
                            <option <?= ($r['attendance_status'] ?? '') === 'EXCUSED' ? 'selected' : '' ?>>EXCUSED</option>
                        </select>
                    </td>
                    <td><input name="remarks" value="<?= e($r['remarks'] ?? '') ?>" placeholder="Optional"></td>
                    <td><button class="btn secondary sm">Save</button></td>
                    </form>
                </tr>
                <?php endforeach; ?>
                <?php if (!$rows): ?>
                <tr><td colspan="6" class="empty">No enrolled beneficiaries match the selected filters.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</section>

<section class="notice">
    <strong>Attendance rule:</strong> One attendance record is allowed per beneficiary per date. Saving the same beneficiary/date updates the existing record instead of creating a duplicate.
</section>
<?php require __DIR__ . '/partials/footer.php'; ?>
