document.addEventListener('DOMContentLoaded', () => {
  const h = document.getElementById('height_cm');
  const w = document.getElementById('weight_kg');
  const out = document.getElementById('bmi_preview');

  function calc() {
    if (!h || !w || !out) return;
    const heightCm = parseFloat(h.value);
    const weightKg = parseFloat(w.value);
    if (heightCm > 0 && weightKg > 0) {
      const meters = heightCm / 100;
      out.value = (weightKg / (meters * meters)).toFixed(2);
    } else {
      out.value = '';
    }
  }
  h?.addEventListener('input', calc);
  w?.addEventListener('input', calc);

  // Optional "capture baseline now" section on the Add Beneficiary form.
  const toggle = document.getElementById('capture_baseline_toggle');
  const fields = document.getElementById('baseline_fields');
  if (toggle && fields) {
    const sync = () => {
      fields.style.display = toggle.checked ? 'grid' : 'none';
      fields.querySelectorAll('input').forEach((el) => {
        if (!toggle.checked) el.value = '';
      });
    };
    toggle.addEventListener('change', sync);
    sync();
  }

  // Soft-lock warning when recording Midline/Endline without a prior milestone on file.
  const milestoneSelect = document.getElementById('milestone_select');
  const milestoneWarning = document.getElementById('milestone_warning');
  if (milestoneSelect && milestoneWarning) {
    const sync2 = () => {
      const selected = milestoneSelect.selectedOptions[0];
      const gapLabel = selected ? selected.getAttribute('data-gap') : '';
      if (gapLabel) {
        milestoneWarning.textContent = 'Heads up: no ' + gapLabel + ' is on file for this child yet. You can still save this record, but comparisons against ' + gapLabel + ' won\u2019t be possible until it\u2019s added.';
        milestoneWarning.style.display = 'block';
      } else {
        milestoneWarning.style.display = 'none';
      }
    };
    milestoneSelect.addEventListener('change', sync2);
    sync2();
  }
});
